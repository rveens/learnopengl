#-*- coding: UTF-8 -*-

"""
All possible errors.
"""

class AssimpError(BaseException):
    """
    If an internal error occures.
    """
    pass