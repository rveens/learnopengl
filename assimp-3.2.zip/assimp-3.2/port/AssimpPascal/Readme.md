See the [AssimpPascal headers here](https://github.com/ev1313/Pascal-Assimp-Headers) (by Tim Blume / ev1313).
